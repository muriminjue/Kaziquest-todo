<template>
  <!-- footer component -->
  <div class="w-100 footer">
    <p class="text-center">Drag and drop to reorder list</p>
  </div>
</template>
